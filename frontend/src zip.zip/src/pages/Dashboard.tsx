import React from "react";

export default function Dashboard() {
  return <h2>Dashboard Page</h2>;
}
