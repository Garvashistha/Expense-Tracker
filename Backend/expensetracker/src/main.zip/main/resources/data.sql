INSERT INTO expense (title, amount, category) VALUES ('Groceries', 1500, 'Food');
INSERT INTO expense (title, amount, category) VALUES ('Bus Ticket', 50, 'Travel');
INSERT INTO expense (title, amount, category) VALUES ('Netflix', 500, 'Entertainment');
